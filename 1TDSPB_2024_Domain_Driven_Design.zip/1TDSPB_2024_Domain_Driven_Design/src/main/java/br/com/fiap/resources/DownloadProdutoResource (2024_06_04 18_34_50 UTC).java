package br.com.fiap.resources;

public class DownloadProdutoResource {

}
